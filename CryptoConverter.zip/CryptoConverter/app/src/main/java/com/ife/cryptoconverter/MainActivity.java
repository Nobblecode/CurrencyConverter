package com.ife.cryptoconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText ed1;
    Spinner sp1,sp2;
    Button bt1;
    public static final String TEXT = "\001B[0m";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1 = findViewById(R.id.ed1);
        sp1 = findViewById(R.id.from);
        sp2 = findViewById(R.id.to);
        bt1 = findViewById(R.id.bt1);

        String[] from = {"Bitcoin","Etherium","Polkadot","Shiba","Doge"};
        ArrayAdapter ad = new ArrayAdapter<String>(this,R.layout.support_simple_spinner_dropdown_item, from);
        sp1.setAdapter(ad);

        String[] to = {"US Dollar"};
        ArrayAdapter ad1 = new ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item, to);
        sp2.setAdapter(ad1);


        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double first;
                Double Amount = Double.parseDouble(ed1.getText().toString()) ;
                if(sp1.getSelectedItem().toString() == "Bitcoin" && sp2.getSelectedItem().toString() == "US Dollar" ){
                    first = Amount*4100.70;
                    Toast.makeText(getApplicationContext(),first.toString(),Toast.LENGTH_LONG).show();
                }
                else if(sp1.getSelectedItem().toString() == "Etherium" && sp2.getSelectedItem().toString() == "US Dollar"){

                    first = Amount*3085.90;
                    Toast.makeText(getApplicationContext(),first.toString(),Toast.LENGTH_LONG).show();
                }
                else if(sp1.getSelectedItem().toString() == "Polkadot" && sp2.getSelectedItem().toString() == "US Dollar"){

                    first = Amount*18.10;
                    Toast.makeText(getApplicationContext(),first.toString(), Toast.LENGTH_LONG).show();
                }
                else if(sp1.getSelectedItem().toString() == "Shiba" && sp2.getSelectedItem().toString() == "US Dollar"){

                    first = Amount*0.03;
                    Toast.makeText(getApplicationContext(),first.toString(),Toast.LENGTH_LONG).show();
                }
                else if(sp1.getSelectedItem().toString() == "Doge" && sp2.getSelectedItem().toString() == "US Dollar"){

                    first = Amount*0.14;
                    Toast.makeText(getApplicationContext(),
                            first.toString(),
                            Toast.LENGTH_LONG).show();
                }


            }
        });

    }
}